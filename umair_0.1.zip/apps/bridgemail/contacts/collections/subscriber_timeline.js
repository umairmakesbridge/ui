define([
	'backbone', 'app', 'contacts/models/subscriber_timeline'
], function (Backbone, app, Timeline) {
        'use strict';
	return Backbone.Collection.extend({
		model: Timeline,
		url: function () {
                    return '/pms/io/subscriber/getData/?BMS_REQ_TK=' + app.get('bms_token') + '&type=timeline&isFuture=N';
		},
                parse: function(response,sent) {
                    var result = []
                    if(!app.checkError(response) && app.checkError(response)){
                        return false;
                    }
                    if(response.totalCount && response.totalCount!=="0"){
                        _.each(response.activities[0],function(val,key){                                                                                    
                            val[0]._id = sent.data.offset + parseInt(key.substring(8));                            
                            result.push(val[0]);
                        })                    
                    }
                    return result;
                }
	});
});
